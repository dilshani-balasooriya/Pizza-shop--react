import "./App.css";
import Navbar from "./Components/Navbar.js"
import Footer from "./Components/Footer.js";
import Home from "./Pages/Home.js";
import Menu from "./Pages/Menu.js";
import About from "./Pages/About.js";
import Contact from "./Pages/Contact.js";
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';

function App() {
  return (
    <div className="App">
      <Router>
        <Navbar />
        <div className="content">
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/menu" element={<Menu />} />
            <Route path="/about" element={<About />} />
            <Route path="/contact" element={<Contact/>} />
          </Routes>
        </div>
        <Footer />
      </Router>
    </div>
  );
}

export default App;